
public class TestAction {
	
//	create an execute method
	public String execute() {
		
		System.out.println("execute() method called");
		return "success";
	}

}
